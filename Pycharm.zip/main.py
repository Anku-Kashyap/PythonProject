from pymodbus.client.sync_diag import ModbusTcpClient

# create a Modbus TCP/IP client
client = ModbusTcpClient('127.0.0.1', port=1502)

# connect to the client
client.connect()

# read a single register at address 0x0000
result = client.read_holding_registers(4035, 1)

# print the value of the register
print(result.registers[0])

# close the client connection
client.close()
